﻿using System;
using System.Collections.Generic;

namespace ASWPacket
{
    public class CAWSPacketReader
    {
        //0번은 무조건 id이기 때문에 1번부터 읽어 온다.
        int m_CurReadPosition = 1;
        List<string> m_Items = new List<string>();
        // 역시나 람다는 프로퍼티만 json형식으로 바꿀수 있다.
        public List<string> Items
        {
            get => m_Items;
            set => m_Items = value;
        }
        public eProtocolID ID
        {
            get => (eProtocolID)Convert.ToInt32(m_Items[0]);
        }
        #region ReadFunctions
        public bool ReadBoolean()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToBoolean(data);
        }
        public virtual byte ReadByte()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToByte(data);
        }
        public virtual char ReadChar()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToChar(data);
        }
        public virtual decimal ReadDecimal()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToDecimal(data);
        }
        public virtual double ReadDouble()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToDouble(data);
        }
        public virtual short ReadInt16()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToInt16(data);
        }
        public virtual int ReadInt32()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToInt32(data);
        }
        public virtual long ReadInt64()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToInt64(data);
        }
        public virtual sbyte ReadSByte()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToSByte(data);
        }
        public virtual float ReadSingle()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToSingle(data);
        }
        public virtual string ReadString()
        {
            var data = m_Items[m_CurReadPosition++];
            return data;
        }
        public virtual ushort ReadUInt16()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToUInt16(data);
        }
        public virtual uint ReadUInt32()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToUInt32(data);
        }
        public virtual ulong ReadUInt64()
        {
            var data = m_Items[m_CurReadPosition++];
            return Convert.ToUInt64(data);
        }
        #endregion
    }
}
