﻿using System.Collections.Generic;

namespace ASWPacket
{
    public class CAWSPacketWriter
    {
        protected eProtocolID ProtocolID;
        List<string> m_Items = new List<string>();
        //람다에서는 프로퍼티만 json형식으로 변환 된다.
        public List<string> Items
        {
            get
            {
                return m_Items;
            }
        }
        public CAWSPacketWriter(eProtocolID protocolID)
        {
            ProtocolID = protocolID;
            Write((int)protocolID);
        }
        /// <summary>
        /// protocolid 값을 세팅한다.
        /// </summary>
        /// <param name="ID"></param>
        public void SetID(eProtocolID ID)
        {
            //같은 값이면 바꿔주지 않는다.
            if (ID == ProtocolID) return;
            //만약 id값이 있을경우는 데이터에서 삭제를 해준다.
            if (ProtocolID != eProtocolID.NONE)
            {
                m_Items.RemoveAt(0);
            }
            //맨처음은 무조건 id이다.
            m_Items.Insert(0, ((int)ID).ToString());
        }
        #region WriteFunctions
        public void Write(ulong value) => m_Items.Add(value.ToString());
        public void Write(uint value) => m_Items.Add(value.ToString());
        public void Write(ushort value) => m_Items.Add(value.ToString());
        public void Write(string value) => m_Items.Add(value);
        public void Write(float value) => m_Items.Add(value.ToString());
        public void Write(sbyte value) => m_Items.Add(value.ToString());
        public void Write(long value) => m_Items.Add(value.ToString());
        public void Write(int value) => m_Items.Add(value.ToString());
        public void Write(double value) => m_Items.Add(value.ToString());
        public void Write(decimal value) => m_Items.Add(value.ToString());
        public void Write(char ch) => m_Items.Add(ch.ToString());
        public void Write(byte value) => m_Items.Add(value.ToString());
        public void Write(bool value) => m_Items.Add(value.ToString());
        public void Write(short value) => m_Items.Add(value.ToString());
        #endregion
    }
}
