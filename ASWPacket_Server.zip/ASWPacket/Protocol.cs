﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASWPacket
{
    public enum eProtocolID {NONE = -1 ,A,B,C,D,E,F }
}
